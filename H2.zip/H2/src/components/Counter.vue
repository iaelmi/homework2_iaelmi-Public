<template>
    <main class="main" id="app">
        <h1>Counter Exercise</h1>
        <article class="counter">
            <h2>
                The count is {{evenOrOdd()}}!
            </h2>
            <p class="count">{{count}}</p>
            <button 
                v-on:click="add">
                Increment by {{amount}}
            </button>
            <button  
                v-on:click="subtract">
                Decrement by {{amount}}
            </button>
            <div class="input-group">
                <label for="amount">Amount</label>
                <input 
                    type="number" 
                    name="amount" 
                    v-model.number="amount" 
                />
            </div>
            <button 
                v-on:click="reset" id="reset">
                Reset count
            </button>
        </article>
    </main>
</template>

<script>
    export default {
        name: 'Counter',
        data: function(){
            return {
                amount: 1, // Default addition and subtraction amount
                count: 0
            }
        },
        methods: {
            reset: function(){
                // Reset total count to 0
                this.count = 0
            },
            // Increase count by increment amount
            add: function(){
                // Add amount to total
                this.count += this.amount
            },
            evenOrOdd: function(){
                // Returns whether counter is even or odd
                if(this.count % 2 === 0)
                    return "even"
                return "odd" 
            },
            subtract: function(){
                // Subract from total count
                this.count -= this.amount
            },
            
        }

    }
</script>

<style>
    .counter {
        border: 3px solid #222;
        border-radius: 8px;
        margin: 30px;
        padding: 30px;
        text-align: center;
        background: #eee;
        box-sizing: border-box;
    }
  
    .count {
        font-size: 3rem;
        font-weight: bold;
        margin-top: 0;
        margin-bottom: 15px;
    }
    
    .input-group {
        display: block;
        margin-top: 30px;
    }
    
    button {
        font-size: 1rem;
        padding: 10px;
    }
    
    h1 {
        text-align: center;
    }
    
    h2 {
        margin-top: 0;
    }

    #reset{
    margin-top: 20px;
    }

</style>
